var app = angular.module('myLang', [])
    .provider('myLang',function(){


    });


